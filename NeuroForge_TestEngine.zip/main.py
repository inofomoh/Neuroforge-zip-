print("✅ NeuroForge Engine is running!")
print("🚀 Welcome to NeuroForge Test Engine")
print("You can now add 3D features, assets, gameplay logic, and rendering systems.")