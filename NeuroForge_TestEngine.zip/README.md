# NeuroForge Engine (Test Version)
This is a minimal test version of the NeuroForge Engine designed to check if it runs on GitHub Codespaces using only a phone.

## How to Run
1. Open this repo in GitHub Codespaces
2. Run: `python3 main.py`
3. You will see a basic engine confirmation message.